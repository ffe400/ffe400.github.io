jQuery(function($){
  $('#slides').bxSlider({
    controls:false,
    pagerCustom:'#myPager',
    mode:'horizontal',
    auto:true,
    autoControls:true
  });
  $c=$('.slider-wrap .bx-wrapper .bx-controls-auto .bx-stop');
  $p=$('.slider-wrap .bx-wrapper .bx-controls-auto .bx-start');
  $c.on('click',function(){
    $c.hide();$p.show();
  })
  $p.on('click',function(){
    $c.show();$p.hide();
  })
});